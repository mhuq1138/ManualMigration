//
//  Message+CoreDataClass.swift
//  EmailApp
//
//  Created by Mazharul Huq on 3/10/18.
//  Copyright © 2018 Mazharul Huq. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Message)
public class Message: NSManagedObject {

}
