//
//  ImageAttachment+CoreDataProperties.swift
//  EmailApp
//
//  Created by Mazharul Huq on 3/21/18.
//  Copyright © 2018 Mazharul Huq. All rights reserved.
//
//

import Foundation
import CoreData


extension ImageAttachment {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ImageAttachment> {
        return NSFetchRequest<ImageAttachment>(entityName: "ImageAttachment")
    }

    @NSManaged public var caption: String?
    @NSManaged public var height: Double
    @NSManaged public var image: NSObject?
    @NSManaged public var width: NSDecimalNumber?

}
