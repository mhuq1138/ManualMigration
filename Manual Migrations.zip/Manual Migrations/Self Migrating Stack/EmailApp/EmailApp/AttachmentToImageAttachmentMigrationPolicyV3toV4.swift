//
//  AttachmentToImageAttachmentMigrationPolicyV3toV4.swift
//  EmailApp
//
//  Created by Mazharul Huq on 3/21/18.
//  Copyright © 2018 Mazharul Huq. All rights reserved.
//

import UIKit
import CoreData

let errorDomain = "Migration"

class AttachmentToImageAttachmentMigrationPolicyV3toV4: NSEntityMigrationPolicy {
    
    override func createDestinationInstances(forSource sInstance: NSManagedObject, in mapping: NSEntityMapping, manager: NSMigrationManager) throws {
        print("Here 1")
        let description = NSEntityDescription.entity(forEntityName: "ImageAttachment", in: manager.destinationContext)
        let newAttachment = ImageAttachment(entity: description!, insertInto: manager.destinationContext)
        
        func traversePropertyMappings(block: (NSPropertyMapping, String) -> ()) throws {
            
            print("Here 2")
            if let attributeMappings = mapping.attributeMappings {
                for propertyMapping in attributeMappings {
                    if let destinationName = propertyMapping.name {
                        block(propertyMapping, destinationName)
                    } else {
                        let message = "Attribute destination not configured properly"
                        let userInfo = [NSLocalizedFailureReasonErrorKey: message]
                        throw NSError(domain: errorDomain, code: 0, userInfo: userInfo)
                    }
                }
            } else {
                print("Here 3")
                let message = "No Attribute Mappings found!"
                let userInfo = [NSLocalizedFailureReasonErrorKey: message]
                throw NSError(domain: errorDomain, code: 0, userInfo: userInfo)
            }
        }
        
        try traversePropertyMappings { propertyMapping, destinationName in
            print("Here 4")
            guard let valueExpression = propertyMapping.valueExpression else { return }
            
            let context: NSMutableDictionary = ["source": sInstance]
            guard let destinationValue = valueExpression.expressionValue(with: sInstance, context: context) else { return }
            
            newAttachment.setValue(destinationValue, forKey: destinationName)
        }
        
        if let image = sInstance.value(forKey: "image") as? UIImage {
            print("Here 5")
            newAttachment.setValue(image.size.width, forKey: "width")
            newAttachment.setValue(image.size.height, forKey: "height")
        }
        
        let caption = sInstance.value(forKeyPath: "message.title") as? NSString ?? ""
        newAttachment.setValue(caption, forKey: "caption")
        
        manager.associate(sourceInstance: sInstance, withDestinationInstance: newAttachment, for: mapping)
    }
}

