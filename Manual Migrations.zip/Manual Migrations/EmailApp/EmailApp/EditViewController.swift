//
//  EditViewController.swift
//  EmailApp
//
//  Created by Mazharul Huq on 3/9/18.
//  Copyright © 2018 Mazharul Huq. All rights reserved.
//

import UIKit
import CoreData

class EditViewController: UIViewController {
    
    @IBOutlet var recipientField: UITextField!
    @IBOutlet var titleField: UITextField!
    @IBOutlet var bodyField: UITextView!
    
    @IBOutlet var dateSentLabel: UILabel!
    var managedContext:NSManagedObjectContext!
    var message:Message?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        self.dateSentLabel.text = ""
        
        if let message = self.message  {
            recipientField.text = message.recipient
            titleField.text = message.title
            bodyField.text = message.body
            dateSentLabel.text = "Sent: \(dateFormatter.string(from: message.dateSent! as Date))"
            
        }
    }
    
    @IBAction func saveTapped(_ sender: Any) {
        if self.message == nil{
            self.message = Message(context: self.managedContext)
        }
        self.message?.recipient = self.recipientField.text
        self.message?.title = self.titleField.text
        self.message?.body = self.bodyField.text
        self.message?.dateSent = NSDate()
        
        do {
            try self.managedContext.save()
            
        } catch let error as NSError {
            print("Could not save \(error), \(error.userInfo)")
        }
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func cancelTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

