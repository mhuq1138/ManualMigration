//
//  Message+CoreDataProperties.swift
//  EmailApp
//
//  Created by Mazharul Huq on 3/9/18.
//  Copyright © 2018 Mazharul Huq. All rights reserved.
//
//

import Foundation
import CoreData


extension Message {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Message> {
        return NSFetchRequest<Message>(entityName: "Message")
    }

    @NSManaged public var title: String?
    @NSManaged public var recipient: String?
    @NSManaged public var body: String?
    @NSManaged public var dateSent: NSDate?

}
