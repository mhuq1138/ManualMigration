//
//  ListViewController.swift
//  EmailApp
//
//  Created by Mazharul Huq on 3/9/18.
//  Copyright © 2018 Mazharul Huq. All rights reserved.
//

import UIKit
import CoreData

class ListViewController: UITableViewController {

    var coreDataStack = CoreDataStack(modelName: "EmailList")
    
    lazy var fetchedResultsController: NSFetchedResultsController<Message> = {
        // Initialize Fetch Request
        let fetchRequest: NSFetchRequest<Message> = Message.fetchRequest()
        
        // Add Sort Descriptors
        let titleSort = NSSortDescriptor(key: "title", ascending: true)
        fetchRequest.sortDescriptors = [titleSort]
        
        // Initialize Fetched Results Controller
        let fetchedResultsController = NSFetchedResultsController<Message>(fetchRequest: fetchRequest, managedObjectContext: self.coreDataStack.managedContext, sectionNameKeyPath: nil, cacheName: nil)
        
        // Configure Fetched Results Controller
        fetchedResultsController.delegate = self
        return fetchedResultsController
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.leftBarButtonItem = self.editButtonItem
        do {
            try fetchedResultsController.performFetch()
        }
        catch{ let nserror = error as NSError
            print("Cannot perform fetch \(nserror.localizedDescription)")
        }
        
    }
    
    func configureCell(_ cell: UITableViewCell, indexPath: IndexPath) {
        let message = fetchedResultsController.object(at: indexPath)
        
        cell.textLabel?.text = message.recipient ?? ""
        cell.detailTextLabel?.text = message.title ?? ""
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        guard let sections = fetchedResultsController.sections else
        {
            return 0
        }
        return sections.count
        
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let sectionInfo = fetchedResultsController.sections?[section]
            else
        {
            return 0
        }
        return sectionInfo.numberOfObjects
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as UITableViewCell
        
        configureCell(cell, indexPath: indexPath)
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let message = self.fetchedResultsController.object(at: indexPath)
            self.fetchedResultsController.managedObjectContext.delete(message)
            do{
                try self.fetchedResultsController.managedObjectContext.save()
            }
            catch{
                print("Cannot delete record from store")
            }
            
        }
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let vc = segue.destination as? EditViewController else{
            print("Storyboard misconfigured")
            return
        }
        vc.managedContext = self.fetchedResultsController.managedObjectContext
        if segue.identifier == "edit"{
            if let indexPath = self.tableView.indexPathForSelectedRow {
                vc.message = fetchedResultsController.object(at: indexPath)
            }
        }
    }
}

//NSFetchedResultsController Delegate methods

extension ListViewController:NSFetchedResultsControllerDelegate{
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.beginUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            tableView.insertRows(at: [newIndexPath!],with: .automatic)
        case .delete:
            tableView.deleteRows(at: [indexPath!],with: .automatic)
        case .update:
            let cell = tableView.cellForRow(at: indexPath!)as UITableViewCell!
            configureCell(cell!, indexPath: indexPath!)
        case .move:
            tableView.deleteRows(at: [indexPath!],with: .automatic)
            tableView.insertRows(at: [newIndexPath!],with: .automatic)
        }
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
        let indexSet = IndexSet(integer: sectionIndex)
        switch type {
        case .insert:
            tableView.insertSections(indexSet,with: .automatic)
        case .delete:
            tableView.deleteSections(indexSet,with: .automatic)
        default :
            break
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.endUpdates()
    }
}

