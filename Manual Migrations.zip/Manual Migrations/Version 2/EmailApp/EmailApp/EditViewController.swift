//
//  EditViewController.swift
//  EmailApp
//
//  Created by Mazharul Huq on 3/9/18.
//  Copyright © 2018 Mazharul Huq. All rights reserved.
//

import UIKit
import CoreData

class EditViewController: UIViewController {
    
    @IBOutlet var recipientField: UITextField!
    @IBOutlet var titleField: UITextField!
    @IBOutlet var bodyField: UITextView!
    @IBOutlet var dateSentLabel: UILabel!
    @IBOutlet var imageView: UIImageView!
    
    var managedContext:NSManagedObjectContext!
    var message:Message?
    var image:UIImage?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        self.dateSentLabel.text = ""
        
        if let message = self.message  {
            recipientField.text = message.recipient
            titleField.text = message.title
            bodyField.text = message.body
            dateSentLabel.text = "Sent: \(dateFormatter.string(from: message.dateSent! as Date))"
            if let image = message.imageAttachment{
                self.imageView.image = image
            }
            
        }
    }
    
    @IBAction func saveTapped(_ sender: Any) {
        if self.message == nil{
            self.message = Message(context: self.managedContext)
        }
        self.message?.recipient = self.recipientField.text
        self.message?.title = self.titleField.text
        self.message?.body = self.bodyField.text
        self.message?.dateSent = NSDate()
        if let image = self.image{
            self.message?.imageAttachment = image
        }
        
        do {
            try self.managedContext.save()
            
        } catch let error as NSError {
            print("Could not save \(error), \(error.userInfo)")
        }
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func cancelTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func attachImageTapped(_ sender: Any) {
        let picker = UIImagePickerController()
        picker.allowsEditing = true
        picker.delegate = self
        present(picker, animated: true, completion: nil)
    }
    
}

extension EditViewController:UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        var newImage: UIImage
        
        if let possibleImage = info[UIImagePickerControllerEditedImage] as? UIImage {
            newImage = possibleImage
        } else if let possibleImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            newImage = possibleImage
        } else {
            return
        }
        
        dismiss(animated: true, completion: nil)
        self.image = newImage
        self.imageView.image = newImage
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    
}
